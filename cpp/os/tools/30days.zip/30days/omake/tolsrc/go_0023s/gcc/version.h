#ifndef GCC_VERSION_H
#define GCC_VERSION_H
extern const char *const version_string;
#endif /* ! GCC_VERSION_H */
